using UnityEngine;

[RequireComponent(typeof(Rigidbody))]

public class PlayerMotor : MonoBehaviour
{

    [SerializeField] private Camera cam;

    private Vector3 velocity = Vector3.zero;
    private Vector3 Rotation = Vector3.zero;
    private Vector3 cameraRotation = Vector3.zero;

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();

    }

    //Gets a movement vector
    public void Move(Vector3 _velocity)
    {
        velocity = _velocity;

    }

    //Gets a rotational vector
    public void Rotate(Vector3 _Rotation)
    {
        Rotation = _Rotation;

    }

    //Gets a rotational vector for the camera
    public void RotateCamera(Vector3 _cameraRotation)
    {
        cameraRotation = _cameraRotation;

    }

    //Runs every physics iteration
    void FixedUpdate()
    {
        PerformMovement();
        PerformRotation();
    }

    //Perform movement based on velocity variable
    void PerformMovement()
    {
        if (velocity != Vector3.zero)
        {
            rb.MovePosition(rb.position + velocity * Time.fixedDeltaTime);
        }
    }

    void PerformRotation()
    {
        rb.MoveRotation(rb.rotation * Quaternion.Euler(Rotation));

        if (cam != null)
        {
            cam.transform.Rotate (-cameraRotation);
        }
    }


}
