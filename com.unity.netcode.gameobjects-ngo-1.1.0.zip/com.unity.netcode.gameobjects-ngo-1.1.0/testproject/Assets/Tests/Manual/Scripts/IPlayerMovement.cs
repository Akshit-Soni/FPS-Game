namespace TestProject.ManualTests
{
    public interface IPlayerMovement
    {
        void Move(int speed);
    }
}
