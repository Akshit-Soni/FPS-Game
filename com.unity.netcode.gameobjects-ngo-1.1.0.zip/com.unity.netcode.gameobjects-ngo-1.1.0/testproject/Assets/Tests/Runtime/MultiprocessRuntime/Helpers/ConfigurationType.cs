
public enum ConfigurationType
{
    Unknown,
    Remote,
    CommandLine,
    ResourceFile,
    Host
}
