namespace Unity.Netcode
{
    internal struct ReleasedNetworkId
    {
        public ulong NetworkId;
        public float ReleaseTime;
    }
}
