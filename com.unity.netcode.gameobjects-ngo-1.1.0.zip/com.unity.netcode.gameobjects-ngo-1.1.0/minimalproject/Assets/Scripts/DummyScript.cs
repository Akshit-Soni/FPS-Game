using UnityEngine;

public class DummyScript : MonoBehaviour
{
}
